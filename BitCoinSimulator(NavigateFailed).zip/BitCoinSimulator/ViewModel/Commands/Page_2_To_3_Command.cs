﻿using BitCoinSimulator.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace BitCoinSimulator.ViewModel.Commands
{
    class Page_2_To_3_Command : ICommand
    {
        Tutorial_Page_Navigate_VM VMRef { get; set; }

        public Page_2_To_3_Command(Tutorial_Page_Navigate_VM vm)
        {
            VMRef = vm;
        }

        public event EventHandler CanExecuteChanged;

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            VMRef.NavigateTo(VMRef.currentPage + 1);
        }
    }
}
