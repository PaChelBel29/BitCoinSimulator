﻿using BitCoinSimulator.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
//201911907 CSE Div. 조훈희

namespace BitCoinSimulator.ViewModel.Commands
{
    class StartCommand : ICommand
    {
        Tutorial_Page_Navigate_VM VMRef { get; set; }

        public StartCommand(Tutorial_Page_Navigate_VM vm)
        {
            VMRef = vm;
        }
        public bool CanExecute(object parameter)
        {
            return true;
        }
        public event EventHandler CanExecuteChanged;

        public void Execute(object parameter)
        {
            //if (Properties.Save_Data.Default.is_Saved)
            //{
            //    //Save 데이터에

            //    //Page Maingame = new Main();
            //    //Application.Current.MainWindow.Content = Maingame;
            //}
            //else
            //{
            VMRef.NavigateTo(VMRef.currentPage + 1);
            //}

        }
    }
}
