﻿using BitCoinSimulator.ViewModel.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace BitCoinSimulator.ViewModel
{
    class Tutorial_Page_Navigate_VM
    {
        public int currentPage { get; set; }
        public StartCommand StartCommand { get; set; }
        public Page_1_To_2_Command Page_1_To_2_Command { get; set; }
        public Page_2_To_3_Command Page_2_To_3_Command { get; set; }
        public SetTheNameCommand SetTheNameCommand { get; set; }

        List<string> PageNames; 
        Frame frame;

        public Tutorial_Page_Navigate_VM(){
            StartCommand = new StartCommand(this);
            Page_1_To_2_Command = new Page_1_To_2_Command(this);
            Page_2_To_3_Command = new Page_2_To_3_Command(this);
            SetTheNameCommand = new SetTheNameCommand(this);

            PageNames = new List<string>();
            PageNames.Add("Start.xaml");
            PageNames.Add("Tutorial_Page.xaml");
            PageNames.Add("Tutorial_Page_2.xaml");
            PageNames.Add("SetNamePage.xaml");

            frame = (Frame)Application.Current.MainWindow.FindName("PageFrame");
        }
        public void NavigateTo(int PageNum)
        {
            currentPage = PageNum;
            frame.NavigationService.Navigate(new Uri(PageNames[currentPage], UriKind.Relative));
        }
    }
}
