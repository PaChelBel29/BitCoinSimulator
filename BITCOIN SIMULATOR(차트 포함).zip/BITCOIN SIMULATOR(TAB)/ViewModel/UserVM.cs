﻿using BITCOIN_SIMULATOR_TAB_.Model;
using BITCOIN_SIMULATOR_TAB_.ViewModel.Commands;

//201918351 장정우
namespace BITCOIN_SIMULATOR_TAB_.ViewModel
{
    class UserVM
    {
        public static UserData Usr { get; set; }
        public BuyCommand buyCom { get; set; }
        public SellCommand sellCom { get; set; }

        public UserVM()
        {
            Usr = new UserData();
            buyCom = new BuyCommand(this);
            sellCom = new SellCommand(this);
            Usr.UserMoney = 100000000;
        }
    }
}
