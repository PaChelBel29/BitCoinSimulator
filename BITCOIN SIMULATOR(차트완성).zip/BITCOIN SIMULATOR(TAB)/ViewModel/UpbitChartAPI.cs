﻿using BITCOIN_SIMULATOR_TAB_.Model;
using LiveCharts;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

//201918351 장정우
namespace BITCOIN_SIMULATOR_TAB_.ViewModel
{
    class UpbitChartAPI
    {
        public ChartValues<int> priceList = new ChartValues<int>();
        static string BASE_URL = "https://api.upbit.com/v1/candles/days?market={0}&to=2021-05-{1}%2009%3A00%3A00&count=30&convertingPriceUnit=KRW";

        public UpbitChartAPI(string coinName, string date)
        {
            List<UpbitData> myList = new List<UpbitData>();

            UpbitData result = new UpbitData();

            string url = string.Format(BASE_URL, coinName, date);

            HttpClient client = new HttpClient();
            var response = client.GetAsync(url);
            string resultString = response.Result.Content.ReadAsStringAsync().Result;
            client.Dispose();
            myList = (List<UpbitData>)JsonConvert.DeserializeObject(resultString, typeof(List<UpbitData>));

            for (int i = 29; i >= 0; i--)
            {
                priceList.Add((int)myList[i].Trade_price);
            }
        }
    }
}
